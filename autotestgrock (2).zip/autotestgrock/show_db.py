import sqlite3

def show_db(db_path="hr_test.db"):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    print("=" * 70)
    print(" СОДЕРЖИМОЕ БАЗЫ ДАННЫХ")
    print("=" * 70)

    # Сотрудники
    rows = cursor.execute("SELECT id, first_name, last_name, email, is_active FROM employees_hr").fetchall()
    print(f"\n СОТРУДНИКИ ({len(rows)}):")
    for r in rows:
        active = "да" if r["is_active"] else "нет"
        print(f"  {r['id']:2}. {r['first_name']} {r['last_name']} | {r['email']} | {active}")

    # Пользователи
    rows = cursor.execute("SELECT id, username, role FROM users_hr").fetchall()
    print(f"\n ПОЛЬЗОВАТЕЛИ ({len(rows)}):")
    for r in rows:
        print(f"  {r['id']:2}. {r['username']} ({r['role']})")

    # Отделы
    rows = cursor.execute("SELECT id, name FROM departments_hr").fetchall()
    print(f"\n ОТДЕЛЫ ({len(rows)}):")
    for r in rows:
        print(f"  {r['id']:2}. {r['name']}")

    # Должности
    rows = cursor.execute("SELECT id, title FROM positions_hr").fetchall()
    print(f"\n ДОЛЖНОСТИ ({len(rows)}):")
    for r in rows:
        print(f"  {r['id']:2}. {r['title']}")

    # Отпуска
    rows = cursor.execute("SELECT id, employee_id, start_date, end_date, status FROM vacations_hr").fetchall()
    print(f"\n ОТПУСКА ({len(rows)}):")
    for r in rows:
        print(f"  {r['id']:2}. Сотр.{r['employee_id']} | {r['start_date']} → {r['end_date']} | {r['status']}")

    # Кандидаты
    rows = cursor.execute("SELECT id, first_name, last_name, status FROM candidates_hr").fetchall()
    print(f"\n КАНДИДАТЫ ({len(rows)}):")
    for r in rows:
        print(f"  {r['id']:2}. {r['first_name']} {r['last_name']} | {r['status']}")

    conn.close()
    print("\n" + "=" * 70)

if __name__ == "__main__":
    show_db()