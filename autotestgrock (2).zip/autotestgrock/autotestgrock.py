import json
import time
import pytest
import sqlite3
from dataclasses import dataclass
from typing import Optional, List, Dict
from datetime import datetime, timedelta

# ★★★ ГЛОБАЛЬНЫЙ СЧЁТЧИК ДЛЯ УНИКАЛЬНЫХ НОМЕРОВ ★★★
_counter = 0

# ============================================================================
# ЧАСТЬ 1: SQLite БАЗА ДАННЫХ
# ============================================================================

class Database:
    def __init__(self, db_path: str = ":memory:"):
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()
        self._create_tables()
        self._seed_data()

    def _create_tables(self):
        self.cursor.executescript("""
            CREATE TABLE IF NOT EXISTS employees_hr (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                middle_name TEXT,
                position_id INTEGER NOT NULL,
                department_id INTEGER NOT NULL,
                email TEXT NOT NULL,
                phone TEXT,
                hire_date TEXT NOT NULL,
                is_active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                personnel_number TEXT UNIQUE,
                birth_date TEXT,
                education TEXT,
                specialty TEXT,
                experience TEXT,
                address TEXT
            );
            
            CREATE TABLE IF NOT EXISTS users_hr (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                email TEXT NOT NULL,
                role TEXT CHECK(role IN ('hr', 'manager', 'admin', 'employee')) NOT NULL,
                employee_id INTEGER,
                last_login TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                is_blocked INTEGER DEFAULT 0,
                FOREIGN KEY (employee_id) REFERENCES employees_hr(id)
            );
            
            CREATE TABLE IF NOT EXISTS departments_hr (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE TABLE IF NOT EXISTS positions_hr (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                salary_min REAL,
                salary_max REAL,
                department_id INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (department_id) REFERENCES departments_hr(id)
            );
            
            CREATE TABLE IF NOT EXISTS vacations_hr (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id INTEGER NOT NULL,
                start_date TEXT NOT NULL,
                end_date TEXT NOT NULL,
                type TEXT CHECK(type IN ('annual', 'sick', 'unpaid', 'maternity')) DEFAULT 'annual',
                status TEXT CHECK(status IN ('pending', 'approved', 'rejected', 'cancelled')) DEFAULT 'pending',
                reason TEXT,
                approved_by INTEGER,
                approved_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees_hr(id),
                FOREIGN KEY (approved_by) REFERENCES users_hr(id)
            );
            
            CREATE TABLE IF NOT EXISTS candidates_hr (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                middle_name TEXT,
                email TEXT,
                phone TEXT,
                position TEXT,
                status TEXT CHECK(status IN ('new', 'review', 'interview', 'offered', 'hired', 'rejected')) DEFAULT 'new',
                birth_date TEXT,
                notes TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE TABLE IF NOT EXISTS vacancies_hr (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                salary_min REAL,
                salary_max REAL,
                department_id INTEGER,
                status TEXT CHECK(status IN ('open', 'closed', 'on_hold')) DEFAULT 'open',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                closed_at TEXT,
                FOREIGN KEY (department_id) REFERENCES departments_hr(id)
            );
            
            CREATE TABLE IF NOT EXISTS employee_history_hr (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                field_name TEXT,
                old_value TEXT,
                new_value TEXT,
                changed_by INTEGER,
                changed_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees_hr(id)
            );
            
            CREATE INDEX IF NOT EXISTS idx_employees_hr_email ON employees_hr(email);
            CREATE INDEX IF NOT EXISTS idx_employees_hr_active ON employees_hr(is_active);
            CREATE INDEX IF NOT EXISTS idx_vacations_hr_status ON vacations_hr(status);
            CREATE INDEX IF NOT EXISTS idx_candidates_hr_status ON candidates_hr(status);
        """)
        self.conn.commit()

    def _seed_data(self):
        self.cursor.executemany(
            "INSERT OR IGNORE INTO departments_hr (id, name, description) VALUES (?, ?, ?)",
            [(1, 'IT', 'Информационные технологии'), (2, 'HR', 'Отдел кадров'),
             (3, 'Финансы', 'Финансовый департамент'), (4, 'Маркетинг', 'Отдел маркетинга'),
             (5, 'Продажи', 'Отдел продаж')]
        )

        self.cursor.executemany(
            "INSERT OR IGNORE INTO positions_hr (id, title, salary_min, salary_max, department_id) VALUES (?, ?, ?, ?, ?)",
            [(1, 'Разработчик', 80000, 150000, 1), (2, 'HR-менеджер', 50000, 80000, 2),
             (3, 'Бухгалтер', 60000, 100000, 3), (4, 'Маркетолог', 55000, 90000, 4),
             (5, 'Менеджер по продажам', 45000, 120000, 5)]
        )

        self.cursor.executemany(
            """INSERT OR IGNORE INTO employees_hr 
               (id, first_name, last_name, middle_name, position_id, department_id, email, phone, hire_date, is_active, personnel_number)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            [(1, 'Никита', 'Иванов', 'Иванович', 1, 1, 'ivan@test.com', '+7 (999) 111-22-33', '2024-01-15', 1, 'P-00001'),
             (2, 'Петр', 'Петров', 'Петрович', 2, 2, 'petr@test.com', '+7 (999) 222-33-44', '2023-05-20', 1, 'P-00002'),
             (3, 'Мария', 'Сидорова', None, 3, 3, 'maria@test.com', '+7 (999) 333-44-55', '2022-08-10', 1, 'P-00003')]
        )

        self.cursor.executemany(
            """INSERT OR IGNORE INTO users_hr 
               (id, username, password_hash, email, role, employee_id, is_blocked)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            [(1, 'admin', 'admin123', 'admin@test.com', 'admin', None, 0),
             (2, 'hr_user', 'hr123', 'hr@test.com', 'hr', None, 0),
             (3, 'manager', 'manager123', 'manager@test.com', 'manager', None, 0),
             (4, 'employee', 'employee123', 'employee@test.com', 'employee', 1, 0)]
        )
        self.conn.commit()

    def execute(self, query: str, params: tuple = ()):
        self.cursor.execute(query, params)
        self.conn.commit()
        return self.cursor

    def fetchone(self, query: str, params: tuple = ()):
        self.cursor.execute(query, params)
        return self.cursor.fetchone()

    def fetchall(self, query: str, params: tuple = ()):
        self.cursor.execute(query, params)
        return self.cursor.fetchall()

    def close(self):
        self.conn.close()


# ============================================================================
# ЧАСТЬ 2: ГЕНЕРАТОР ДАННЫХ
# ============================================================================

class SimpleFaker:
    @staticmethod
    def first_name():
        return ["Александр", "Дмитрий", "Максим", "Анна", "Екатерина",
                "Сергей", "Алексей", "Мария", "Ольга", "Иван"][int(time.time()) % 10]

    @staticmethod
    def last_name():
        return ["Иванов", "Петров", "Сидоров", "Смирнов", "Кузнецов",
                "Попов", "Соколов", "Михайлов", "Фёдоров", "Морозов"][int(time.time() * 2) % 10]

    @staticmethod
    def email():
        return f"test_{int(time.time())}_{int(time.time() * 3)}@test.com"

    @staticmethod
    def phone():
        return f"+7(9{int(time.time()) % 10}){int(time.time()) % 10000000:07d}"

    @staticmethod
    def first_name_male():
        return SimpleFaker.first_name()

    @staticmethod
    def random_number(digits=5):
        return int(time.time()) % (10 ** digits)

    @staticmethod
    def random_element(items):
        return items[int(time.time()) % len(items)]

    @staticmethod
    def date_of_birth(minimum_age=18, maximum_age=65):
        year = 2026 - minimum_age - (int(time.time()) % (maximum_age - minimum_age))
        return datetime(year, (int(time.time()) % 12) + 1, (int(time.time()) % 28) + 1)

    @staticmethod
    def date_between(start_date="-10y", end_date="today"):
        return datetime(2020 + (int(time.time()) % 6), (int(time.time()) % 12) + 1, (int(time.time()) % 28) + 1)

    @staticmethod
    def address():
        return f"г. Москва, ул. {SimpleFaker.last_name()}, д. {int(time.time()) % 100}"


# ============================================================================
# ЧАСТЬ 3: МОК-ЗАГЛУШКА ДЛЯ REQUESTS
# ============================================================================

class MockResponse:
    def __init__(self, json_data, status_code=200):
        self.json_data = json_data
        self.status_code = status_code
        self.text = json.dumps(json_data)

    def json(self):
        return self.json_data

    def raise_for_status(self):
        if self.status_code >= 400:
            error = Exception(f"HTTP {self.status_code}: {self.json_data}")
            error.response = self
            error.status_code = self.status_code
            raise error

    @property
    def ok(self):
        return self.status_code < 400


class MockRequests:
    _db = Database("hr_test.db")  # ← БД сохранится в файл
    _faker = SimpleFaker()

    @classmethod
    def _check_token(cls, headers):
        auth = headers.get("Authorization", "")
        if not auth or not auth.startswith("Bearer "):
            error = Exception("Unauthorized: No token provided")
            error.status_code = 401
            raise error
        token = auth.replace("Bearer ", "")
        if not token or not token.startswith("fake_token_"):
            error = Exception("Unauthorized: Invalid token")
            error.status_code = 401
            raise error
        return True

    @classmethod
    def _get_user_from_token(cls, headers):
        auth = headers.get("Authorization", "")
        if not auth or not auth.startswith("Bearer "):
            return None
        token = auth.replace("Bearer ", "")
        if not token or not token.startswith("fake_token_"):
            return None
        username = token.replace("fake_token_", "").split("_")[0]
        user = cls._db.fetchone("SELECT * FROM users_hr WHERE username = ?", (username,))
        return dict(user) if user else None

    @classmethod
    def _dict_from_row(cls, row):
        return {key: row[key] for key in row.keys()} if row else None

    @classmethod
    def get(cls, url, **kwargs):
        headers = kwargs.get("headers", {})
        params = kwargs.get("params", {})
        db = cls._db

        if "/auth/me" in url:
            cls._check_token(headers)
            return MockResponse({"id": 1, "username": "admin", "email": "admin@test.com", "role": "admin"})

        elif "/employees" in url:
            cls._check_token(headers)
            parts = url.split("/")
            if parts and parts[-1].isdigit():
                emp = db.fetchone("SELECT * FROM employees_hr WHERE id = ?", (int(parts[-1]),))
                return MockResponse(cls._dict_from_row(emp) or {"detail": "Not found"}, 404 if not emp else 200)

            search = params.get("search", "")
            if search:
                pattern = f"%{search}%"
                rows = db.fetchall("SELECT * FROM employees_hr WHERE first_name LIKE ? OR last_name LIKE ? OR email LIKE ?",
                                   (pattern, pattern, pattern))
                return MockResponse([cls._dict_from_row(r) for r in rows])

            dept_id = params.get("department_id")
            if dept_id:
                rows = db.fetchall("SELECT * FROM employees_hr WHERE department_id = ?", (int(dept_id),))
                return MockResponse([cls._dict_from_row(r) for r in rows])

            rows = db.fetchall("SELECT * FROM employees_hr")
            return MockResponse([cls._dict_from_row(r) for r in rows])

        elif "/vacations" in url:
            cls._check_token(headers)
            parts = url.split("/")
            if parts and parts[-1].isdigit():
                vac = db.fetchone("SELECT * FROM vacations_hr WHERE id = ?", (int(parts[-1]),))
                return MockResponse(cls._dict_from_row(vac) or {"detail": "Not found"}, 404 if not vac else 200)
            rows = db.fetchall("SELECT * FROM vacations_hr")
            return MockResponse([cls._dict_from_row(r) for r in rows])

        elif "/departments" in url:
            cls._check_token(headers)
            rows = db.fetchall("SELECT * FROM departments_hr")
            return MockResponse([cls._dict_from_row(r) for r in rows])

        elif "/positions" in url:
            cls._check_token(headers)
            rows = db.fetchall("SELECT * FROM positions_hr")
            return MockResponse([cls._dict_from_row(r) for r in rows])

        elif "/candidates" in url:
            cls._check_token(headers)
            rows = db.fetchall("SELECT * FROM candidates_hr")
            return MockResponse([cls._dict_from_row(r) for r in rows])

        elif "/vacancies" in url:
            cls._check_token(headers)
            rows = db.fetchall("SELECT * FROM vacancies_hr")
            return MockResponse([cls._dict_from_row(r) for r in rows])

        elif "/history" in url:
            cls._check_token(headers)
            parts = url.split("/")
            rows = db.fetchall("SELECT * FROM employee_history_hr WHERE employee_id = ?", (int(parts[-2]),))
            return MockResponse([cls._dict_from_row(r) for r in rows])

        return MockResponse({"detail": "Not found"}, 404)

    @classmethod
    def post(cls, url, **kwargs):
        data = kwargs.get("json", {})
        headers = kwargs.get("headers", {})
        db = cls._db
        faker = cls._faker
        global _counter

        if "/auth/login" in url:
            user = db.fetchone("SELECT * FROM users_hr WHERE username = ?", (data.get("username"),))
            if not user or user["password_hash"] != data.get("password"):
                return MockResponse({"detail": "Invalid credentials"}, 401)
            token = f"fake_token_{data.get('username')}_{int(time.time())}"
            return MockResponse({
                "access_token": token,
                "token_type": "bearer",
                "user": {"id": user["id"], "username": user["username"], "email": user["email"], "role": user["role"]}
            })

        elif "/auth/register" in url:
            if db.fetchone("SELECT * FROM users_hr WHERE username = ?", (data.get("username"),)):
                return MockResponse({"detail": "User already exists"}, 400)
            db.execute("INSERT INTO users_hr (username, password_hash, email, role) VALUES (?, ?, ?, ?)",
                       (data.get("username"), data.get("password"), data.get("email"), "employee"))
            return MockResponse({"id": db.cursor.lastrowid, "message": "User created"}, 201)

        elif "/employees" in url:
            cls._check_token(headers)
            user = cls._get_user_from_token(headers)
            if user and user.get("role") not in ["hr", "admin"]:
                return MockResponse({"detail": "Forbidden"}, 403)
            if not data.get("firstName") or not data.get("lastName") or not data.get("email"):
                return MockResponse({"detail": "Missing required fields"}, 400)

            _counter += 1
            personnel_number = data.get("personnelNumber") or f"P-{int(time.time())}_{_counter:06d}"

            db.execute("""
                INSERT INTO employees_hr 
                (first_name, last_name, middle_name, email, phone, department_id, position_id, 
                 hire_date, is_active, personnel_number, birth_date, education, specialty, experience, address)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                data.get("firstName"), data.get("lastName"), data.get("middleName", ""),
                data.get("email"), data.get("phone", ""), data.get("departmentId", 1),
                data.get("positionId", 1), data.get("hireDate", "2024-01-01"),
                data.get("isActive", 1), personnel_number,
                data.get("birthDate", "1990-01-01"), data.get("education", "Высшее"),
                data.get("specialty", "Информационные технологии"),
                data.get("experience", "5 лет"), data.get("address", "г. Москва, ул. Тестовая, д. 1")
            ))
            new_id = db.cursor.lastrowid
            new_emp = db.fetchone("SELECT * FROM employees_hr WHERE id = ?", (new_id,))
            return MockResponse(cls._dict_from_row(new_emp), 201)

        elif "/vacations" in url:
            cls._check_token(headers)
            if not data.get("employeeId"):
                return MockResponse({"detail": "Employee ID required"}, 400)
            if not db.fetchone("SELECT * FROM employees_hr WHERE id = ?", (data["employeeId"],)):
                return MockResponse({"detail": "Employee not found"}, 404)
            start = datetime.strptime(data.get("startDate"), "%Y-%m-%d")
            end = datetime.strptime(data.get("endDate"), "%Y-%m-%d")
            if (end - start).days > 60:
                return MockResponse({"detail": "Vacation exceeds 60 days"}, 400)
            db.execute("""
                INSERT INTO vacations_hr (employee_id, start_date, end_date, type, status, reason)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (data.get("employeeId"), data.get("startDate"), data.get("endDate"),
                  data.get("type", "annual"), "pending", data.get("reason", "Ежегодный отпуск")))
            new_id = db.cursor.lastrowid
            return MockResponse(cls._dict_from_row(db.fetchone("SELECT * FROM vacations_hr WHERE id = ?", (new_id,))), 201)

        elif "/candidates" in url:
            cls._check_token(headers)
            user = cls._get_user_from_token(headers)
            if user and user.get("role") not in ["hr", "admin"]:
                return MockResponse({"detail": "Forbidden"}, 403)
            if not data.get("firstName") or not data.get("lastName"):
                return MockResponse({"detail": "First and last name required"}, 400)
            db.execute("""
                INSERT INTO candidates_hr (first_name, last_name, middle_name, email, phone, position, status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (data.get("firstName"), data.get("lastName"), data.get("middleName", ""),
                  data.get("email", ""), data.get("phone", ""), data.get("position", ""),
                  data.get("status", "new"), data.get("notes", "")))
            new_id = db.cursor.lastrowid
            new_cand = db.fetchone("SELECT * FROM candidates_hr WHERE id = ?", (new_id,))
            return MockResponse({
                "id": new_cand["id"],
                "firstName": new_cand["first_name"],
                "lastName": new_cand["last_name"],
                "middleName": new_cand["middle_name"],
                "email": new_cand["email"],
                "phone": new_cand["phone"],
                "position": new_cand["position"],
                "status": new_cand["status"],
                "notes": new_cand["notes"],
            }, 201)

        elif "/vacancies" in url:
            cls._check_token(headers)
            user = cls._get_user_from_token(headers)
            if user and user.get("role") not in ["hr", "admin"]:
                return MockResponse({"detail": "Forbidden"}, 403)
            if not data.get("title"):
                return MockResponse({"detail": "Title required"}, 400)
            db.execute("""
                INSERT INTO vacancies_hr (title, description, salary_min, salary_max, department_id, status)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (data.get("title"), data.get("description", ""),
                  data.get("salary_min"), data.get("salary_max"),
                  data.get("department_id", 1), data.get("status", "open")))
            new_id = db.cursor.lastrowid
            return MockResponse(cls._dict_from_row(db.fetchone("SELECT * FROM vacancies_hr WHERE id = ?", (new_id,))), 201)

        return MockResponse({"detail": "Not found"}, 404)

    @classmethod
    def put(cls, url, **kwargs):
        data = kwargs.get("json", {})
        headers = kwargs.get("headers", {})
        db = cls._db

        if "/employees" in url:
            parts = url.split("/")
            if parts and parts[-1].isdigit():
                cls._check_token(headers)
                emp_id = int(parts[-1])
                updates, params = [], []
                for field, key in [("first_name", "firstName"), ("last_name", "lastName"),
                                   ("middle_name", "middleName"), ("email", "email"), ("phone", "phone"),
                                   ("department_id", "departmentId"), ("position_id", "positionId"),
                                   ("is_active", "isActive")]:
                    if key in data:
                        updates.append(f"{field} = ?")
                        params.append(data[key])
                if not updates:
                    return MockResponse({"detail": "No fields to update"}, 400)
                params.append(emp_id)
                db.execute(f"UPDATE employees_hr SET {', '.join(updates)} WHERE id = ?", tuple(params))
                updated = db.fetchone("SELECT * FROM employees_hr WHERE id = ?", (emp_id,))
                return MockResponse(cls._dict_from_row(updated) or {"detail": "Employee not found"}, 404 if not updated else 200)

        elif "/auth/change-password" in url:
            cls._check_token(headers)
            user = cls._get_user_from_token(headers)
            if not user or user.get("password_hash") != data.get("old_password"):
                return MockResponse({"detail": "Invalid old password"}, 400)
            db.execute("UPDATE users_hr SET password_hash = ? WHERE id = ?", (data.get("new_password"), user["id"]))
            return MockResponse({"message": "Password changed"})

        return MockResponse({"detail": "Not found"}, 404)

    @classmethod
    def patch(cls, url, **kwargs):
        headers = kwargs.get("headers", {})
        db = cls._db

        if "/approve" in url:
            cls._check_token(headers)
            parts = url.split("/")
            vac_id = int(parts[-2])
            vac = db.fetchone("SELECT * FROM vacations_hr WHERE id = ?", (vac_id,))
            if not vac:
                return MockResponse({"detail": "Vacation not found"}, 404)
            if vac["status"] == "rejected":
                return MockResponse({"detail": "Cannot approve rejected"}, 400)
            db.execute("UPDATE vacations_hr SET status = 'approved', approved_by = ?, approved_at = ? WHERE id = ?",
                       (1, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), vac_id))
            return MockResponse(cls._dict_from_row(db.fetchone("SELECT * FROM vacations_hr WHERE id = ?", (vac_id,))))

        elif "/reject" in url:
            cls._check_token(headers)
            parts = url.split("/")
            vac_id = int(parts[-2])
            vac = db.fetchone("SELECT * FROM vacations_hr WHERE id = ?", (vac_id,))
            if not vac:
                return MockResponse({"detail": "Vacation not found"}, 404)
            if vac["status"] == "approved":
                return MockResponse({"detail": "Cannot reject approved"}, 400)
            db.execute("UPDATE vacations_hr SET status = 'rejected' WHERE id = ?", (vac_id,))
            return MockResponse(cls._dict_from_row(db.fetchone("SELECT * FROM vacations_hr WHERE id = ?", (vac_id,))))

        return MockResponse({"detail": "Not found"}, 404)

    @classmethod
    def delete(cls, url, **kwargs):
        headers = kwargs.get("headers", {})
        db = cls._db

        if "/employees" in url:
            parts = url.split("/")
            if parts and parts[-1].isdigit():
                cls._check_token(headers)
                emp_id = int(parts[-1])

                user = cls._get_user_from_token(headers)
                if user and user.get("role") not in ["hr", "admin"]:
                    return MockResponse({"detail": "Forbidden"}, 403)

                db.execute("UPDATE employees_hr SET is_active = 0 WHERE id = ?", (emp_id,))

                if db.cursor.rowcount > 0:
                    return MockResponse({"message": "Employee deactivated"})
                return MockResponse({"detail": "Employee not found"}, 404)

        elif "/vacations" in url:
            parts = url.split("/")
            if parts and parts[-1].isdigit():
                cls._check_token(headers)
                vac_id = int(parts[-1])
                db.execute("DELETE FROM vacations_hr WHERE id = ?", (vac_id,))
                if db.cursor.rowcount > 0:
                    return MockResponse({"message": "Vacation deleted"})
                return MockResponse({"detail": "Vacation not found"}, 404)

        return MockResponse({"detail": "Not found"}, 404)


# ============================================================================
# ЧАСТЬ 4: ПОДМЕНЯЕМ REAL REQUESTS
# ============================================================================

class RequestsModule:
    get = MockRequests.get
    post = MockRequests.post
    put = MockRequests.put
    patch = MockRequests.patch
    delete = MockRequests.delete

import sys
sys.modules['requests'] = RequestsModule


# ============================================================================
# ЧАСТЬ 5: КОНФИГУРАЦИЯ
# ============================================================================

@dataclass
class TestConfig:
    BASE_URL: str = "http://localhost:8000"
    API_PREFIX: str = "/api"
    ADMIN_USERNAME: str = "admin"
    ADMIN_PASSWORD: str = "admin123"
    HR_USERNAME: str = "hr_user"
    HR_PASSWORD: str = "hr123"
    MANAGER_USERNAME: str = "manager"
    MANAGER_PASSWORD: str = "manager123"
    EMPLOYEE_USERNAME: str = "employee"
    EMPLOYEE_PASSWORD: str = "employee123"
    REQUEST_TIMEOUT: int = 30

config = TestConfig()


# ============================================================================
# ЧАСТЬ 6: МОДЕЛИ ДАННЫХ
# ============================================================================

@dataclass
class User:
    id: int
    username: str
    email: str
    role: str
    employee_id: Optional[int] = None
    is_blocked: bool = False


@dataclass
class AuthResponse:
    access_token: str
    token_type: str
    user: User

    @classmethod
    def from_dict(cls, data: dict) -> "AuthResponse":
        user_data = data.get("user", {})
        return cls(
            access_token=data.get("access_token"),
            token_type=data.get("token_type"),
            user=User(
                id=user_data.get("id"),
                username=user_data.get("username"),
                email=user_data.get("email"),
                role=user_data.get("role"),
                employee_id=user_data.get("employee_id"),
                is_blocked=user_data.get("is_blocked", False),
            )
        )


@dataclass
class Employee:
    id: Optional[int] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    middle_name: Optional[str] = None
    position_id: Optional[int] = None
    department_id: Optional[int] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    hire_date: Optional[str] = None
    is_active: bool = True
    personnel_number: Optional[str] = None
    birth_date: Optional[str] = None
    education: Optional[str] = None
    specialty: Optional[str] = None
    experience: Optional[str] = None
    address: Optional[str] = None

    def to_dict(self) -> dict:
        mapping = {"first_name": "firstName", "last_name": "lastName", "middle_name": "middleName",
                   "position_id": "positionId", "department_id": "departmentId", "hire_date": "hireDate",
                   "is_active": "isActive", "personnel_number": "personnelNumber", "birth_date": "birthDate"}
        return {mapping.get(k, k): v for k, v in self.__dict__.items() if v is not None}

    @classmethod
    def from_dict(cls, data: dict) -> "Employee":
        if not data:
            return cls()

        # ★★★ ПРЕОБРАЗУЕМ is_active В БУЛЕВО ★★★
        is_active = data.get("isActive")
        if is_active is None:
            is_active = data.get("is_active")

        if isinstance(is_active, int):
            is_active = bool(is_active)
        elif is_active is None:
            is_active = True

        return cls(
            id=data.get("id"),
            first_name=data.get("firstName") or data.get("first_name"),
            last_name=data.get("lastName") or data.get("last_name"),
            middle_name=data.get("middleName") or data.get("middle_name"),
            position_id=data.get("positionId") or data.get("position_id"),
            department_id=data.get("departmentId") or data.get("department_id"),
            email=data.get("email"),
            phone=data.get("phone"),
            hire_date=data.get("hireDate") or data.get("hire_date"),
            is_active=is_active,
            personnel_number=data.get("personnelNumber") or data.get("personnel_number"),
            birth_date=data.get("birthDate") or data.get("birth_date"),
            education=data.get("education"),
            specialty=data.get("specialty"),
            experience=data.get("experience"),
            address=data.get("address"),
        )


@dataclass
class Vacation:
    id: Optional[int] = None
    employee_id: Optional[int] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    type: str = "annual"
    status: str = "pending"
    reason: Optional[str] = None
    approved_by: Optional[int] = None

    def to_dict(self) -> dict:
        mapping = {"employee_id": "employeeId", "start_date": "startDate", "end_date": "endDate",
                   "approved_by": "approvedBy"}
        return {mapping.get(k, k): v for k, v in self.__dict__.items() if v is not None}

    @classmethod
    def from_dict(cls, data: dict) -> "Vacation":
        if not data:
            return cls()
        return cls(
            id=data.get("id"),
            employee_id=data.get("employeeId") or data.get("employee_id"),
            start_date=data.get("startDate") or data.get("start_date"),
            end_date=data.get("endDate") or data.get("end_date"),
            type=data.get("type", "annual"),
            status=data.get("status", "pending"),
            reason=data.get("reason"),
            approved_by=data.get("approvedBy") or data.get("approved_by"),
        )


@dataclass
class Department:
    id: Optional[int] = None
    name: Optional[str] = None
    description: Optional[str] = None

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if v is not None}

    @classmethod
    def from_dict(cls, data: dict) -> "Department":
        return cls(id=data.get("id"), name=data.get("name"), description=data.get("description"))


@dataclass
class Candidate:
    id: Optional[int] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    middle_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    position: Optional[str] = None
    status: str = "new"
    notes: Optional[str] = None

    def to_dict(self) -> dict:
        mapping = {"first_name": "firstName", "last_name": "lastName", "middle_name": "middleName"}
        return {mapping.get(k, k): v for k, v in self.__dict__.items() if v is not None}

    @classmethod
    def from_dict(cls, data: dict) -> "Candidate":
        if not data:
            return cls()
        return cls(
            id=data.get("id"),
            first_name=data.get("firstName") or data.get("first_name"),
            last_name=data.get("lastName") or data.get("last_name"),
            middle_name=data.get("middleName") or data.get("middle_name"),
            email=data.get("email"),
            phone=data.get("phone"),
            position=data.get("position"),
            status=data.get("status", "new"),
            notes=data.get("notes"),
        )


# ============================================================================
# ЧАСТЬ 7: ГЕНЕРАТОР ТЕСТОВЫХ ДАННЫХ
# ============================================================================

class DataGenerator:
    @staticmethod
    def first_name() -> str:
        return SimpleFaker.first_name()

    @staticmethod
    def last_name() -> str:
        return SimpleFaker.last_name()

    @staticmethod
    def middle_name() -> str:
        return SimpleFaker.first_name_male() + "ович"

    @staticmethod
    def email() -> str:
        return SimpleFaker.email()

    @staticmethod
    def phone() -> str:
        return SimpleFaker.phone()

    @staticmethod
    def date(years_back: int = 25) -> str:
        return SimpleFaker.date_of_birth(minimum_age=years_back).strftime("%Y-%m-%d")

    @staticmethod
    def hire_date() -> str:
        return SimpleFaker.date_between().strftime("%Y-%m-%d")

    @staticmethod
    def personnel_number() -> str:
        global _counter
        _counter += 1
        return f"P-{int(time.time())}_{_counter:06d}"

    @staticmethod
    def address() -> str:
        return SimpleFaker.address()

    @staticmethod
    def education() -> str:
        return SimpleFaker.random_element(["Высшее", "Среднее специальное", "Высшее (магистратура)", "Высшее (бакалавриат)", "Среднее профессиональное"])

    @staticmethod
    def specialty() -> str:
        return SimpleFaker.random_element(["Программная инженерия", "Экономика", "Педагогика", "Менеджмент", "Информационные технологии", "Бухгалтерский учет"])

    @staticmethod
    def experience() -> str:
        return f"{SimpleFaker.random_number(digits=2)} лет"

    @staticmethod
    def employee(department_id: int = 1, position_id: int = 1, is_active: bool = True) -> Employee:
        return Employee(
            first_name=DataGenerator.first_name(),
            last_name=DataGenerator.last_name(),
            middle_name=DataGenerator.middle_name(),
            department_id=department_id,
            position_id=position_id,
            email=DataGenerator.email(),
            phone=DataGenerator.phone(),
            hire_date=DataGenerator.hire_date(),
            is_active=is_active,
            personnel_number=DataGenerator.personnel_number(),
            birth_date=DataGenerator.date(),
            education=DataGenerator.education(),
            specialty=DataGenerator.specialty(),
            experience=DataGenerator.experience(),
            address=DataGenerator.address(),
        )

    @staticmethod
    def vacation(employee_id: int, start_date: Optional[str] = None, end_date: Optional[str] = None, vacation_type: str = "annual") -> Vacation:
        if start_date is None:
            start_date = (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d")
        if end_date is None:
            end_date = (datetime.now() + timedelta(days=44)).strftime("%Y-%m-%d")
        return Vacation(
            employee_id=employee_id,
            start_date=start_date,
            end_date=end_date,
            type=vacation_type,
            status="pending",
            reason="Ежегодный отпуск",
        )

    @staticmethod
    def candidate() -> Candidate:
        return Candidate(
            first_name=DataGenerator.first_name(),
            last_name=DataGenerator.last_name(),
            middle_name=DataGenerator.middle_name(),
            email=DataGenerator.email(),
            phone=DataGenerator.phone(),
            position="Тестовая позиция",
            status="new",
            notes="Тестовый кандидат",
        )


# ============================================================================
# ЧАСТЬ 8: API КЛИЕНТЫ
# ============================================================================

class BaseAPI:
    def __init__(self):
        self.base_url = config.BASE_URL
        self.api_prefix = config.API_PREFIX
        self.timeout = config.REQUEST_TIMEOUT
        self._token: Optional[str] = None

    @property
    def token(self) -> Optional[str]:
        return self._token

    @token.setter
    def token(self, value: str):
        self._token = value

    def _headers(self, include_auth: bool = True) -> Dict[str, str]:
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if include_auth and self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        return headers

    def _request(self, method: str, endpoint: str, data: Optional[Dict] = None, params: Optional[Dict] = None, include_auth: bool = True):
        url = f"{self.base_url}{self.api_prefix}{endpoint}"
        params = params or {}
        methods = {"GET": RequestsModule.get, "POST": RequestsModule.post, "PUT": RequestsModule.put,
                   "PATCH": RequestsModule.patch, "DELETE": RequestsModule.delete}
        response = methods.get(method.upper(), RequestsModule.get)(
            url, headers=self._headers(include_auth), params=params, json=data
        )
        response.raise_for_status()
        return response


class AuthAPI(BaseAPI):
    def login(self, username: str, password: str) -> AuthResponse:
        response = self._request("POST", "/auth/login", {"username": username, "password": password}, include_auth=False)
        auth_response = AuthResponse.from_dict(response.json())
        self.token = auth_response.access_token
        return auth_response

    def get_current_user(self, token: Optional[str] = None) -> dict:
        if token:
            self.token = token
        return self._request("GET", "/auth/me").json()

    def register(self, username: str, password: str, email: str) -> dict:
        return self._request("POST", "/auth/register", {"username": username, "password": password, "email": email}, include_auth=False).json()

    def change_password(self, old_password: str, new_password: str, token: Optional[str] = None) -> dict:
        if token:
            self.token = token
        return self._request("PUT", "/auth/change-password", {"old_password": old_password, "new_password": new_password}).json()


class EmployeeAPI(BaseAPI):
    def get_all(self, token: Optional[str] = None):
        if token:
            self.token = token
        return [Employee.from_dict(e) for e in self._request("GET", "/employees").json()]

    def get_by_id(self, employee_id: int, token: Optional[str] = None) -> Employee:
        if token:
            self.token = token
        return Employee.from_dict(self._request("GET", f"/employees/{employee_id}").json())

    def create(self, employee: Employee, token: Optional[str] = None) -> Employee:
        if token:
            self.token = token
        return Employee.from_dict(self._request("POST", "/employees", employee.to_dict()).json())

    def update(self, employee_id: int, employee: Employee, token: Optional[str] = None) -> Employee:
        if token:
            self.token = token
        return Employee.from_dict(self._request("PUT", f"/employees/{employee_id}", employee.to_dict()).json())

    def delete(self, employee_id: int, token: Optional[str] = None) -> dict:
        if token:
            self.token = token
        return self._request("DELETE", f"/employees/{employee_id}").json()

    def search(self, query: str, token: Optional[str] = None):
        if token:
            self.token = token
        return [Employee.from_dict(e) for e in self._request("GET", "/employees", params={"search": query}).json()]

    def filter_by_department(self, department_id: int, token: Optional[str] = None):
        if token:
            self.token = token
        return [Employee.from_dict(e) for e in self._request("GET", "/employees", params={"department_id": department_id}).json()]


class VacationAPI(BaseAPI):
    def get_all(self, token: Optional[str] = None):
        if token:
            self.token = token
        return [Vacation.from_dict(v) for v in self._request("GET", "/vacations").json()]

    def get_by_id(self, vacation_id: int, token: Optional[str] = None) -> Vacation:
        if token:
            self.token = token
        return Vacation.from_dict(self._request("GET", f"/vacations/{vacation_id}").json())

    def create(self, vacation: Vacation, token: Optional[str] = None) -> Vacation:
        if token:
            self.token = token
        return Vacation.from_dict(self._request("POST", "/vacations", vacation.to_dict()).json())

    def approve(self, vacation_id: int, token: Optional[str] = None) -> Vacation:
        if token:
            self.token = token
        return Vacation.from_dict(self._request("PATCH", f"/vacations/{vacation_id}/approve").json())

    def reject(self, vacation_id: int, token: Optional[str] = None) -> Vacation:
        if token:
            self.token = token
        return Vacation.from_dict(self._request("PATCH", f"/vacations/{vacation_id}/reject").json())

    def delete(self, vacation_id: int, token: Optional[str] = None) -> dict:
        if token:
            self.token = token
        return self._request("DELETE", f"/vacations/{vacation_id}").json()


class CandidateAPI(BaseAPI):
    def get_all(self, token: Optional[str] = None):
        if token:
            self.token = token
        return [Candidate.from_dict(c) for c in self._request("GET", "/candidates").json()]

    def create(self, candidate: Candidate, token: Optional[str] = None) -> Candidate:
        if token:
            self.token = token
        return Candidate.from_dict(self._request("POST", "/candidates", candidate.to_dict()).json())


# ============================================================================
# ЧАСТЬ 9: FIXTURES
# ============================================================================

_auth_api = AuthAPI()
_employee_api = EmployeeAPI()
_vacation_api = VacationAPI()
_candidate_api = CandidateAPI()

_token_cache = {}

def get_token(role: str) -> str:
    if role in _token_cache:
        return _token_cache[role]
    creds = {"admin": (config.ADMIN_USERNAME, config.ADMIN_PASSWORD),
             "hr": (config.HR_USERNAME, config.HR_PASSWORD),
             "manager": (config.MANAGER_USERNAME, config.MANAGER_PASSWORD),
             "employee": (config.EMPLOYEE_USERNAME, config.EMPLOYEE_PASSWORD)}
    username, password = creds.get(role, (None, None))
    if not username:
        raise ValueError(f"Unknown role: {role}")
    response = _auth_api.login(username, password)
    _token_cache[role] = response.access_token
    return response.access_token


def create_test_employee() -> Employee:
    token = get_token("hr")
    return _employee_api.create(DataGenerator.employee(department_id=1, position_id=1), token=token)


def delete_test_employee(employee_id: int):
    try:
        _employee_api.delete(employee_id, get_token("hr"))
    except Exception:
        pass


def create_test_vacation(employee_id: int) -> Vacation:
    return _vacation_api.create(DataGenerator.vacation(employee_id, vacation_type="annual"), get_token("employee"))


def delete_test_vacation(vacation_id: int):
    try:
        _vacation_api.delete(vacation_id, get_token("hr"))
    except Exception:
        pass


# ============================================================================
# ЧАСТЬ 10: ТЕСТЫ
# ============================================================================

class TestAuth:
    def test_successful_login(self):
        response = _auth_api.login(config.ADMIN_USERNAME, config.ADMIN_PASSWORD)
        assert response.access_token is not None
        assert len(response.access_token) > 0
        assert response.user.username == config.ADMIN_USERNAME
        assert response.user.role == "admin"
        print(" Успешный вход")

    def test_failed_login_wrong_password(self):
        with pytest.raises(Exception):
            _auth_api.login(config.ADMIN_USERNAME, "wrong_password")
        print(" Неверный пароль блокируется")

    def test_failed_login_wrong_username(self):
        with pytest.raises(Exception):
            _auth_api.login("wrong_user", config.ADMIN_PASSWORD)
        print(" Неверный логин блокируется")

    def test_register_new_user(self):
        """Регистрация нового пользователя"""
        username = f"reg_{int(time.time())}_{int(time.time() * 7)}"
        password = "Test@12345"
        email = f"{username}@test.com"

        response = _auth_api.register(username, password, email)
        assert "id" in response
        assert response["id"] is not None

        auth_response = _auth_api.login(username, password)
        assert auth_response.access_token is not None
        print(" Регистрация работает")

    def test_register_duplicate_username(self):
        """Регистрация с уже существующим логином"""
        username = f"dup_{int(time.time())}_{int(time.time() * 11)}"
        password = "Test@12345"
        email = f"{username}@test.com"

        _auth_api.register(username, password, email)

        with pytest.raises(Exception) as exc:
            _auth_api.register(username, "different", email)

        error_text = str(exc.value)
        assert "400" in error_text or "exists" in error_text or "already" in error_text
        print(" Дубликат логина блокируется")

    def test_get_current_user(self):
        token = get_token("admin")
        user_data = _auth_api.get_current_user(token=token)
        assert user_data["username"] == config.ADMIN_USERNAME
        assert user_data["role"] == "admin"
        print(" Получение текущего пользователя")

    def test_get_current_user_invalid_token(self):
        with pytest.raises(Exception):
            _auth_api.get_current_user(token="invalid_token")
        print(" Невалидный токен блокируется")


class TestEmployees:
    def test_create_employee(self):
        token = get_token("hr")
        employee = DataGenerator.employee()
        created = _employee_api.create(employee, token=token)
        assert created.id is not None
        assert created.first_name == employee.first_name
        assert created.last_name == employee.last_name
        assert created.email == employee.email
        assert created.is_active is True
        delete_test_employee(created.id)
        print(" Создание сотрудника")

    def test_create_employee_without_auth(self):
        employee = DataGenerator.employee()
        _employee_api.token = None
        with pytest.raises(Exception):
            _employee_api.create(employee, token=None)
        print(" Без токена создание запрещено")

    def test_get_all_employees(self):
        employees = _employee_api.get_all(get_token("hr"))
        assert isinstance(employees, list)
        assert len(employees) > 0
        assert all(isinstance(e, Employee) for e in employees)
        print(f" Получено {len(employees)} сотрудников")

    def test_get_employee_by_id(self):
        token = get_token("hr")
        created = create_test_employee()
        employee = _employee_api.get_by_id(created.id, token=token)
        assert employee.id == created.id
        assert employee.first_name == created.first_name
        delete_test_employee(created.id)
        print(" Получение сотрудника по ID")

    def test_get_non_existent_employee(self):
        with pytest.raises(Exception):
            _employee_api.get_by_id(999999, get_token("hr"))
        print(" Несуществующий сотрудник не найден")

    def test_update_employee(self):
        token = get_token("hr")
        created = create_test_employee()
        created.first_name = f"Updated_{DataGenerator.first_name()}"
        created.last_name = f"Updated_{DataGenerator.last_name()}"
        updated = _employee_api.update(created.id, created, token=token)
        assert updated.id == created.id
        assert "Updated_" in updated.first_name
        delete_test_employee(created.id)
        print(" Обновление сотрудника")

    def test_search_employee(self):
        token = get_token("hr")
        created = create_test_employee()
        results = _employee_api.search(created.last_name, token=token)
        assert len(results) > 0
        assert any(e.id == created.id for e in results)
        delete_test_employee(created.id)
        print(" Поиск сотрудника")

    def test_deactivate_employee(self):
        token = get_token("hr")
        created = create_test_employee()
        _employee_api.delete(created.id, token=token)
        deactivated = _employee_api.get_by_id(created.id, token=token)
        assert deactivated.is_active is False
        print(" Увольнение сотрудника")


class TestVacations:
    def test_create_vacation(self):
        employee = create_test_employee()
        created = _vacation_api.create(DataGenerator.vacation(employee.id), get_token("employee"))
        assert created.id is not None
        assert created.employee_id == employee.id
        assert created.status == "pending"
        delete_test_vacation(created.id)
        delete_test_employee(employee.id)
        print(" Создание заявки на отпуск")

    def test_get_all_vacations(self):
        employee = create_test_employee()
        vacation = create_test_vacation(employee.id)
        vacations = _vacation_api.get_all(get_token("hr"))
        assert isinstance(vacations, list)
        assert len(vacations) > 0
        delete_test_vacation(vacation.id)
        delete_test_employee(employee.id)
        print(" Получение списка заявок")

    def test_approve_vacation(self):
        employee = create_test_employee()
        vacation = create_test_vacation(employee.id)
        approved = _vacation_api.approve(vacation.id, get_token("manager"))
        assert approved.id == vacation.id
        assert approved.status == "approved"
        delete_test_vacation(vacation.id)
        delete_test_employee(employee.id)
        print(" Утверждение заявки")

    def test_reject_vacation(self):
        employee = create_test_employee()
        vacation = DataGenerator.vacation(employee.id)
        created = _vacation_api.create(vacation, get_token("employee"))
        rejected = _vacation_api.reject(created.id, get_token("manager"))
        assert rejected.id == created.id
        assert rejected.status == "rejected"
        delete_test_vacation(created.id)
        delete_test_employee(employee.id)
        print(" Отклонение заявки")


class TestSecurity:
    def test_access_without_token(self):
        _employee_api.token = None
        with pytest.raises(Exception):
            _employee_api.get_all(token=None)
        print(" Без токена доступ запрещён")

    def test_employee_cannot_delete_employee(self):
        employee = create_test_employee()
        with pytest.raises(Exception):
            _employee_api.delete(employee.id, get_token("employee"))
        delete_test_employee(employee.id)
        print(" Сотрудник не может удалять")

    def test_hr_can_deactivate_employee(self):
        employee = create_test_employee()
        _employee_api.delete(employee.id, get_token("hr"))
        deactivated = _employee_api.get_by_id(employee.id, get_token("hr"))
        assert deactivated.is_active is False
        print(" HR может увольнять")

    def test_admin_has_full_access(self):
        admin_token = get_token("admin")
        employees = _employee_api.get_all(token=admin_token)
        assert len(employees) > 0
        employee = DataGenerator.employee()
        created = _employee_api.create(employee, token=admin_token)
        assert created.id is not None
        _employee_api.delete(created.id, token=admin_token)
        print(" Админ имеет полный доступ")


class TestCandidates:
    def test_create_candidate(self):
        token = get_token("hr")
        candidate = DataGenerator.candidate()
        created = _candidate_api.create(candidate, token=token)
        assert created.id is not None
        assert created.first_name == candidate.first_name
        assert created.last_name == candidate.last_name
        assert created.email == candidate.email
        print(" Создание кандидата")

    def test_get_all_candidates(self):
        candidates = _candidate_api.get_all(get_token("hr"))
        assert isinstance(candidates, list)
        print(f" Получено {len(candidates)} кандидатов")


# ============================================================================
# ЗАПУСК
# ============================================================================

    try:
        token = get_token("admin")
        print(f" Получен токен: {token[:30]}...")
        print()
    except Exception as e:
        print(f" Ошибка: {e}")
        exit(1)

    pytest.main([__file__, "-v", "--tb=short"])